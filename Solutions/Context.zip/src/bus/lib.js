import { Languages } from "./enu";

export const Translate = ( iKey, iLanguage = Languages.Dutch) => {
	//TODO: Implement

	return `${iKey}_${iLanguage}`;
};