export let Languages = Object.freeze({
	Dutch: "nl-be",
	English: "en-us"
});


export const Actions = Object.freeze({
	Toggle_Language: "Toggle_Language"
});