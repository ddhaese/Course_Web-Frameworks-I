import React from "react";
import { SomeComponent } from "./cmp/SomeComponent";

export const App = () => {
	return <SomeComponent />;
};
