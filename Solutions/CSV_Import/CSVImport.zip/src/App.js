import React from "react";
import { Uploader } from "./Uploader";
import { RevisionCheck } from "./RevisionCheck";

export const App = () => {
	return <div id="app">
		<Uploader />
		<RevisionCheck />
	</div>
};
